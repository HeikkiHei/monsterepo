package monster.monstergenerator;

import monster.userInterface.*;

public class Generate {

    public static void main(String[] args) {
        NonGraphicInterface monster = new NonGraphicInterface();
        monster.run();
    }
}
