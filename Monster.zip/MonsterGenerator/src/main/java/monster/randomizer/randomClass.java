
package monster.randomizer;

public class randomClass {
    
}
