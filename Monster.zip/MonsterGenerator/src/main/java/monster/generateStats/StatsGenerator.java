package monster.generateStats;

public class StatsGenerator {

    public int randomStr() {
        return 0;
    }

    public int randomDex() {
        return 0;
    }

    public int randomCon() {
        return 0;
    }

    public int randomInt() {
        return 0;
    }

    public int randomWis() {
        return 0;
    }

    public int randomCha() {
        return 0;
    }

}
