# monsterepo
##Random monster generator

Ohjelma, joka satunnaisgeneroi hirvi�it� ja NPC-hahmoja roolipeli� varten.

###Dokumentaatio
[Aiheen kuvaus](Documentation/aiheenKuvausJaRakenne.md)

[Tuntikirjanpito](Documentation/TUNTIKIRJANPITO.md)
