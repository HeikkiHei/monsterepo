## **Aihe:** Monster generator

**Lyhyt kuvaus:** Toteutetaan ohjelma, joka satunnaisgeneroi hirvi�it� ja NPC-hahmoja roolipeli� varten. Tarkoituksena on ainakin aluksi kehitt�� j�rjestelm�, jolla pystyt��n luomaan satunnainen hahmo tai satunnaisia hahmoja, riippuen k�ytt�j�n valinnasta.

Hahmoille generoidaan erilaisia ominaisuuksia, kuten hahmoluokka, mahdollinen nimi (NPC:t), statistiikka (voima, nopeus, jne), ase ja muut v�lineet.



**K�ytt�j�t:** Ohjelma ei vaadi kirjautumista, joten k�ytt�j� on k�ytt�j�.

**Toiminnot:**
- p��t� tehd��nk� hirvi� vai npc
- p��t� luodun hahmon taso
- luo hahmo

**Luokkakaavio:**
![Kaavion paikka](Monster_luokkakaavio.png "http://yuml.me/edit/f76c0700")


