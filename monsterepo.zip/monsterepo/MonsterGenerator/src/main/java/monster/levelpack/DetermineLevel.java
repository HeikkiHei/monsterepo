package monster.levelpack;

import java.util.*;

public class DetermineLevel {

    Random random = new Random();
    
    
//TODO : Tästä tullee osa GUIn slideria, jolla käyttäjä määrittää haluamansa levelin. Level määrittää monsun tason ja/tai monsujen määrän - Heikki Hei
}
