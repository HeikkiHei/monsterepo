
package monster.randomizer;

public class Randomizer {
    
}
