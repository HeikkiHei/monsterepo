
package monster.randomizer;

public class RandomWeapon {
    
}
