
package monster.randomizer;

public class RandomRace {
    
}
