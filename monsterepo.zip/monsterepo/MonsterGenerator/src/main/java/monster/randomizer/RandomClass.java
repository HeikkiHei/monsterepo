
package monster.randomizer;

public class RandomClass {
    
}
