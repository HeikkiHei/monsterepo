package monster.generateStats;

public class StatsGenerator {
//
//    public int randomStr() {
//        return 0;
//    }
//
//    public int randomDex() {
//        return 0;
//    }
//
//    public int randomCon() {
//        return 0;
//    }
//
//    public int randomInt() {
//        return 0;
//    }
//
//    public int randomWis() {
//        return 0;
//    }
//
//    public int randomCha() {
//        return 0;
//    }
// TODO: Tänne tehdään logiikka, jolla generoidaan semi-random statsit hahmoille. 
// Hahmolla on 1 - lvl+3 maksimi jokaiseen arvoon, eli esim. lvl 5 hahmolla on arvot 1-8 mahdollisia. - Heikki Hei
}
