# monsterepo
##Random monster generator

Ohjelma, joka satunnaisgeneroi hirvi�it� ja NPC-hahmoja roolipeli� varten.

###Dokumentaatio
[Aiheen kuvaus](Documentation/aiheenKuvausJaRakenne.md)

[Tuntikirjanpito](Documentation/TUNTIKIRJANPITO.md)

[Pit-raportti](http://htmlpreview.github.io/?https://github.com/HeikkiHei/monsterepo/blob/master/Documentation/Pit/index.html)